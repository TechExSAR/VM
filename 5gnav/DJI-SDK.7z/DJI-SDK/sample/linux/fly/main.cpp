/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Standard Library Imports
 */
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <regex>
#include <sstream>
#include <string>
#include <vector>
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * DJI SDK Imports
 */
#include "fly_by_waypoints.hpp"
using namespace DJI::OSDK;
using namespace DJI::OSDK::Telemetry;
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Forward Declarations of Utility Functions
 */
std::vector<std::string>
split_by(std::string, char);

std::string trim_string(std::string);

void
process_fields_values(std::string, std::vector<float>*);
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Debugging Tools
 */
template<typename T>
void
print_vec(std::vector<T> vec)
{
  for (auto&& v : vec)
  {
    std::cout.precision(9);
    std::cout << v << ", ";
  }

  std::cout << '\n';
}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Utility Functions
 */
std::string
trim_string(std::string string_to_trim)
{
  return std::regex_replace(string_to_trim, std::regex("^ +| +$|( ) +"), "$1");
}

std::vector<std::string>
split_by(std::string str_to_split, char delimter)
{
  /* delimit the line_from_file we got from the file and strip whitespace */
  std::istringstream       iss(str_to_split);
  std::vector<std::string> tokens;
  std::string              token;

  while (std::getline(iss, token, delimter))
  {
    token = trim_string(token);
    tokens.push_back(token);
  }

  // return vector of split-ed strings
  return tokens;
}

void
process_fields_values(std::string field, std::vector<float>* out)
{
  auto tokens = split_by(field, ',');
  for (auto&& token : tokens)
  {
    out->push_back(std::stof(token));
  }
}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Main Logic
 */
int
main(int argc, char** argv)
{
  /*
   * DJI SDK and Drone Communication Setup
   * */
  // Setup OSDK.
  LinuxSetup linuxEnvironment(argc, argv);
  Vehicle*   vehicle = linuxEnvironment.getVehicle();
  if (vehicle == NULL)
  {
    std::cout << "Vehicle not initialized, exiting.\n";
    return -1;
  }
  // Obtain Control Authority
  int functionTimeout = 1;
  vehicle->obtainCtrlAuthority(functionTimeout);
  /* * * * * * * * * * * * * * * * * * * * * * * * * * * */

  /* argv[0] = program name
   * argv[1] = DJI SDK Developer Keys
   * argv[2] = flight string
   * */
  if (argc >= 3)
  {

    // temporary vectors to hold the info that runWaypointMissions needs for
    // drone flight
    std::vector<float> LATITUDES;
    std::vector<float> LONGITUDES;
    std::vector<float> ALTITUDES;
    int                Number_of_Fields;

    // parse "flight string"
    std::string FLIGHT_STRING = argv[2];
    auto        FIELDS        = split_by(FLIGHT_STRING, '|');

    Number_of_Fields = std::stoi(FIELDS[0]);

    process_fields_values(FIELDS[1], &ALTITUDES);
    process_fields_values(FIELDS[2], &LATITUDES);
    process_fields_values(FIELDS[3], &LONGITUDES);

    int waypointPolygonSides = Number_of_Fields;
    int responseTimeout      = 1;

    //
    print_vec(ALTITUDES);
    print_vec(LATITUDES);
    print_vec(LONGITUDES);
    //

    /* give runWaypointMission,
     * - the temporary vectors
     * - an int defining, in seconds, the timeout for runWaypointMission
     * - assuming all the temporary vectors have the same size,
     *      the size of one of the temporary vectors as waypointPolygonSides
     *
     * this should exit successfully saying that the subscription has been reset
     * */
    runWaypointMission(vehicle,
                       waypointPolygonSides,
                       responseTimeout,
                       ALTITUDES,
                       LATITUDES,
                       LONGITUDES);
  }
  else
  {
    // exit if there are not enough args
    // error message
    std::cout << "NOT ENOUGH CMD LINE ARGS" << '\n';
    // exit with error
    return 1;
  }
  /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

  // exit successfully
  return 0;
}
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
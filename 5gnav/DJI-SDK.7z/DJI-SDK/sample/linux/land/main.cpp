#include "land.hpp"

using namespace DJI::OSDK;
using namespace DJI::OSDK::Telemetry;

/*! main
 *
 */
int
main(int argc, char** argv)
{
  // Initialize variables
  int functionTimeout = 1;

  // Setup OSDK.
  LinuxSetup linuxEnvironment(argc, argv);
  Vehicle*   vehicle = linuxEnvironment.getVehicle();
  if (vehicle == NULL)
  {
    std::cout << "Vehicle not initialized, exiting.\n";
    return -1;
  }

  // Obtain Control Authority
  vehicle->obtainCtrlAuthority(functionTimeout);

  // Display interactive prompt
 // std::cout
   // << "| Available commands:                                            |"
   // << std::endl;
  //std::cout
   // << "| [a] Monitored Landing                                |"
   // << std::endl;
  char inputChar;
  //std::cin >> inputChar;
inputChar='a';	
  switch (inputChar)
  {
    case 'a':
      monitoredLanding(vehicle);
      break;
    default:
      break;
  }

  return 0;
}
